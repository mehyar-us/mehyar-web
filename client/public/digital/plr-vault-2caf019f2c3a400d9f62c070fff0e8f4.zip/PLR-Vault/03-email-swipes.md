# PLR Vault — 50 Email Swipe Files
Replace [BRACKETS] with your details. Every email is written to send as-is.

---

## WELCOME SEQUENCE

### W-1 — The delivery
**Purpose:** Deliver the lead magnet, set the tone.
**Subjects:** "Here's your [LEAD MAGNET] (takes 4 minutes)" / "You asked, I delivered" / "Start here, [FIRST NAME]"
**Body:**
Hey [FIRST NAME],

Your [LEAD MAGNET NAME] is attached — or grab it here: [LINK]

Quick start: skip to page [X]. Do that one thing today and you'll already be ahead of 90% of people who download freebies and never open them.

I'm [YOUR NAME]. I help [AUDIENCE] get [OUTCOME] without [COMMON PAIN]. You'll hear from me a few times a week — always something useful, never fluff. If that's not your thing, unsubscribe below, no hard feelings.

Talk soon,
[YOUR NAME]

### W-2 — The story
**Purpose:** Build connection, earn the open habit.
**Subjects:** "Why I do this (the short version)" / "Nobody asked, but here's my story" / "The part I usually skip"
**Body:**
[FIRST NAME], quick story.

[1-2 sentences: where you were — the frustration, the stuck feeling.]

[1-2 sentences: the shift — what you tried, what finally clicked.]

[1-2 sentences: where you are now and why you teach this.]

I tell you this because if you're where I was, I want you to know the gap is smaller than it looks. Tomorrow I'll share the [FRAMEWORK/CHECKLIST] that changed everything for me.

[YOUR NAME]

P.S. Hit reply and tell me where you're stuck — I read everything.

### W-3 — The quick win
**Purpose:** Deliver value fast, build authority.
**Subjects:** "Do this today, thank me Friday" / "The 10-minute win" / "Steal my [TACTIC]"
**Body:**
Here's something you can use in the next 10 minutes:

[TACTIC NAME]: [2-3 sentence explanation of the tactic.]

Why it works: [one sentence on the mechanism.]

Try it today and reply with your result — I collect these and share the best ones (with your permission).

This is the kind of thing I send every week. Small, usable, no theory.

[YOUR NAME]

### W-4 — The belief shift
**Purpose:** Break the objection stopping them.
**Subjects:** "You're not behind. You're just early." / "The lie keeping you stuck" / "Read this before you quit"
**Body:**
[FIRST NAME], the story you're telling yourself is wrong.

You think: "[COMMON LIMITING BELIEF — e.g. I need a bigger audience first.]"

Reality: [2-3 sentences dismantling it with logic or a mini case study.]

The people getting results aren't smarter or luckier. They just stopped waiting for permission. You already have permission — you had it the whole time.

Tomorrow: the [RESOURCE] I wish someone handed me at the start.

[YOUR NAME]

### W-5 — The soft offer
**Purpose:** First pitch, low pressure.
**Subjects:** "If you want the shortcut..." / "I made this for you" / "The next step (only if you want it)"
**Body:**
Hey [FIRST NAME],

Over the last few days I've shared [RECAP: the story, the tactic, the mindset shift]. If you want to go deeper, I built [PRODUCT NAME] for exactly that.

It's [ONE-LINE DESCRIPTION]. It helps you [OUTCOME] without [PAIN].

Here's the link: [LINK]

No pressure — the free stuff keeps coming either way. But if you're ready to move faster, this is the shortcut.

[YOUR NAME]

## VALUE / NURTURE

### V-1 — The contrarian take
**Purpose:** Stand out, spark replies.
**Subjects:** "Unpopular opinion: [TAKE]" / "Everyone's wrong about [TOPIC]" / "I'm going to get hate for this"
**Body:**
Hot take: [CONTRARIAN OPINION stated plainly.]

Everyone says [COMMON ADVICE]. But [2-3 sentences: why it's wrong or incomplete, with a concrete example].

I'm not saying this to be edgy. I'm saying it because [WHO IT HELPS] keep failing at this, and the advice is why.

Agree or disagree — hit reply. I want to hear your take.

[YOUR NAME]

### V-2 — The teardown
**Purpose:** Teach by example, show expertise.
**Subjects:** "I rewrote [BRAND]'s [PAGE/EMAIL] — here's what I'd change" / "Teardown: [EXAMPLE]" / "Steal this breakdown"
**Body:**
I looked at [EXAMPLE — a landing page, an email, a post] and found 3 things worth stealing:

1. [THING] — why it works: [one line]
2. [THING] — why it works: [one line]
3. [THING] — the fix I'd make: [one line]

The pattern: [ONE-SENTENCE PRINCIPLE].

Save this email. Next time you're stuck on [TASK], run through these three and you'll be 80% there.

[YOUR NAME]

### V-3 — The mistake
**Purpose:** Relatability, teach through failure.
**Subjects:** "My $X mistake (so you don't make it)" / "I wish someone told me this" / "Don't do what I did"
**Body:**
Let me save you [TIME/MONEY]:

I [DESCRIBE THE MISTAKE in 2-3 sentences — specific, not vague].

What I should have done: [THE CORRECT APPROACH in 1-2 sentences].

The lesson cost me [X]. It costs you 2 minutes of reading. That's a trade I'll make for you every time.

What mistake taught you the most? Reply — I read them all.

[YOUR NAME]

### V-4 — The framework
**Purpose:** Signature methodology, memorable teaching.
**Subjects:** "My [X]-step [FRAMEWORK NAME]" / "The only [TOPIC] framework you need" / "Bookmark this"
**Body:**
Whenever I [TASK], I run the same [X]-step framework:

Step 1: [NAME] — [one-line description]
Step 2: [NAME] — [one-line description]
Step 3: [NAME] — [one-line description]

That's it. No 47-step system. Frameworks work because they remove decisions, and decisions are where momentum dies.

I break this down with examples inside [PRODUCT NAME]: [LINK]

[YOUR NAME]

### V-5 — The curated list
**Purpose:** Easy value, high save rate.
**Subjects:** "7 tools I actually pay for" / "My [TOPIC] stack (no fluff)" / "Bookmark: [LIST]"
**Body:**
People ask what I use for [TASK]. Here's the honest list — no affiliate-stuffed garbage, just what runs my business:

1. [TOOL] — for [JOB]. Why: [one line]
2. [TOOL] — for [JOB]. Why: [one line]
3. [TOOL] — for [JOB]. Why: [one line]
4. [TOOL] — for [JOB]. Why: [one line]
5. [TOOL] — for [JOB]. Why: [one line]

Total cost: [X]/month. Everything else is noise.

What's in your stack? Reply and compare notes.

[YOUR NAME]

### V-6 — The myth-bust
**Purpose:** Reframe a belief, position authority.
**Subjects:** "Stop believing [MYTH]" / "[MYTH] is costing you money" / "The truth about [TOPIC]"
**Body:**
You've probably heard: [MYTH].

Here's what's actually true: [2-3 sentences with evidence, logic, or a mini case study].

This matters because [STAKES — what it costs them to keep believing the myth].

I built [PRODUCT NAME] around this exact insight: [LINK]

Stop optimizing for the myth. Start optimizing for what works.

[YOUR NAME]

### V-7 — The behind-the-scenes
**Purpose:** Humanize, build parasocial trust.
**Subjects:** "What I'm working on (the messy middle)" / "No filter today" / "Behind the scenes"
**Body:**
No lesson today. Just real life:

[2-3 sentences: what you're working on, what's hard, what's uncertain. Be specific — "rewriting the checkout page for the third time" beats "hustling hard."]

[1-2 sentences: what you're learning from it.]

Thanks for being here for the unglamorous part. The wins are more fun to share, but this is where they're made.

[YOUR NAME]

### V-8 — The quick tutorial
**Purpose:** Actionable how-to, high forward rate.
**Subjects:** "How to [TASK] in [TIME]" / "Tutorial: [TASK]" / "Do [TASK] with me"
**Body:**
Here's exactly how to [TASK]:

1. [Step — specific, actionable]
2. [Step — specific, actionable]
3. [Step — specific, actionable]
4. [Step — specific, actionable]

Common mistake: [WHAT PEOPLE GET WRONG]. Avoid that and you're golden.

Want the [TEMPLATE/CHECKLIST] version? It's inside [PRODUCT NAME]: [LINK]

[YOUR NAME]

### V-9 — The perspective shift
**Purpose:** Motivational without fluff.
**Subjects:** "You're measuring the wrong thing" / "This changed how I work" / "A reframe for your week"
**Body:**
[FIRST NAME], quick reframe:

You've been measuring [VANITY METRIC — followers, likes, hours worked]. Start measuring [REAL METRIC — replies, sales, shipped projects].

[VANITY METRIC] feels good. [REAL METRIC] pays.

[2 sentences: what changed for you when you switched.]

This week, ignore the [VANITY]. Chase the [REAL]. Report back.

[YOUR NAME]

### V-10 — The FAQ crusher
**Purpose:** Pre-handle objections before the pitch.
**Subjects:** "You asked, I answered" / "The 3 questions I get most" / "FAQ: [TOPIC]"
**Body:**
Three questions I get constantly:

**"[QUESTION 1]?"**
[2-sentence answer.]

**"[QUESTION 2]?"**
[2-sentence answer.]

**"[QUESTION 3]?"**
[2-sentence answer.]

Got a fourth? Reply — if it's good I'll answer it in the next email and credit you.

[YOUR NAME]

## LAUNCH SEQUENCE

### L-1 — The announcement
**Purpose:** Open the launch, build anticipation.
**Subjects:** "Something's coming [DATE]" / "Mark your calendar" / "I've been building something"
**Body:**
Hey [FIRST NAME],

I've been quietly building [PRODUCT NAME] for [TIMEFRAME], and it opens on [DATE].

It's [ONE-LINE DESCRIPTION] for [AUDIENCE] who want [OUTCOME].

Over the next few days I'll show you exactly what's inside, who it's for (and not for), and why I built it this way.

No hype. Just the details, then you decide.

[YOUR NAME]

### L-2 — The problem agitation
**Purpose:** Make the pain vivid before the solution.
**Subjects:** "Does this sound familiar?" / "The [PROBLEM] nobody talks about" / "Still dealing with [PAIN]?"
**Body:**
Tell me if this is you:

[SYMPTOM 1 — specific, visceral]
[SYMPTOM 2 — specific, visceral]
[SYMPTOM 3 — specific, visceral]

That's [PROBLEM NAME]. And it's not your fault — [REASON: bad advice, missing system, no time].

[PRODUCT NAME] exists to fix exactly this. Doors open [DATE]. Tomorrow: what's inside.

[YOUR NAME]

### L-3 — The transformation
**Purpose:** Paint the after-state.
**Subjects:** "Imagine [OUTCOME]" / "What changes when [PROBLEM] is gone" / "The after picture"
**Body:**
Close your eyes for 10 seconds. Imagine:

[BEFORE → AFTER 1: specific contrast]
[BEFORE → AFTER 2: specific contrast]
[BEFORE → AFTER 3: specific contrast]

That's what [PRODUCT NAME] is built to deliver. Not motivation — a [SYSTEM/TEMPLATE/PROCESS] that makes [OUTCOME] the default.

Opens [DATE]. Here's a sneak peek: [LINK]

[YOUR NAME]

### L-4 — The what's-inside
**Purpose:** Detail the offer, kill vagueness.
**Subjects:** "Exactly what's inside [PRODUCT NAME]" / "The full breakdown" / "No more guessing"
**Body:**
Here's everything in [PRODUCT NAME]:

✅ [COMPONENT 1] — [one-line benefit]
✅ [COMPONENT 2] — [one-line benefit]
✅ [COMPONENT 3] — [one-line benefit]
✅ [BONUS 1] — [one-line benefit]
✅ [BONUS 2] — [one-line benefit]

Price: [PRICE]. [GUARANTEE in one line.]

Who it's for: [AUDIENCE + QUALIFIER].
Who it's NOT for: [DISQUALIFIER — builds trust].

Get it here when doors open [DATE]: [LINK]

[YOUR NAME]

### L-5 — Doors open
**Purpose:** The cart-open email. Clear CTA.
**Subjects:** "OPEN: [PRODUCT NAME] is live" / "It's time" / "[PRODUCT NAME] — doors are open"
**Body:**
[FIRST NAME], it's live.

[PRODUCT NAME]: [ONE-LINE DESCRIPTION]
Price: [PRICE]
Get it: [LINK]

Quick recap of what's inside: [3 BULLETS, benefit-led].

[GUARANTEE]: [one line — remove the risk].

Doors close [DATE/TIME]. After that, [WHAT HAPPENS — price goes up / doors close].

[YOUR NAME]

### L-6 — The objection crusher
**Purpose:** Mid-cart objection handling.
**Subjects:** "But what if [OBJECTION]?" / "Fair question" / "Let me guess your hesitation"
**Body:**
Since launching [PRODUCT NAME], the #1 question I've gotten:

"[OBJECTION — e.g. I'm a beginner, will this work for me?]"

Honest answer: [2-3 sentences — direct, no dodging.]

Second most common: "[OBJECTION 2]?"

[2-sentence answer.]

If your question isn't answered, reply — I'm answering everything personally until cart close.

[LINK]

[YOUR NAME]

### L-7 — The story sell
**Purpose:** Emotional close, narrative pitch.
**Subjects:** "Why I built this (the real reason)" / "This one's personal" / "The story behind [PRODUCT NAME]"
**Body:**
I built [PRODUCT NAME] because [PERSONAL STORY — 3-4 sentences: the frustration you lived, the moment you decided to fix it].

Every [COMPONENT] in there exists because I needed it and couldn't find it.

If you're where I was — [DESCRIBE THEIR SITUATION] — this is the shortcut I wish someone handed me.

[LINK] — closes [DATE].

[YOUR NAME]

### L-8 — Final call
**Purpose:** Cart close urgency, honest.
**Subjects:** "Closes tonight" / "Last call: [PRODUCT NAME]" / "[X] hours left"
**Body:**
[FIRST NAME], [PRODUCT NAME] closes in [X] hours.

After [TIME], [WHAT HAPPENS].

No fake scarcity — [REASON IT CLOSES: cohort start / bonus expires / price increases]. When it's gone, it's gone until [NEXT OPPORTUNITY, or "I don't know when"].

If you've been on the fence: [ONE-LINE RISK REVERSAL — guarantee reminder].

[LINK]

Whatever you decide, thanks for reading this far. It means a lot.

[YOUR NAME]

## PROMO / FLASH SALE

### P-1 — Flash sale announce
**Purpose:** Short-window discount, high energy.
**Subjects:** "48 hours: [X]% off [PRODUCT]" / "Flash sale (ends [DAY])" / "Quick one"
**Body:**
Quick heads-up, [FIRST NAME]:

[PRODUCT NAME] is [X]% off for the next 48 hours. [PRICE] instead of [PRICE].

[ONE-LINE REMINDER of what it does.]

[LINK]

No long pitch — you know what it is. Ends [DAY] at [TIME].

[YOUR NAME]

### P-2 — Reason-why sale
**Purpose:** Give the discount a believable reason.
**Subjects:** "Why I'm discounting [PRODUCT]" / "A sale with a reason" / "[OCCASION] sale"
**Body:**
I'm running a [X]% off sale on [PRODUCT NAME], and here's why:

[REASON — 2 sentences: milestone, season, birthday, "I felt like it." Make it human and specific.]

So for [TIMEFRAME]: [PRICE] instead of [PRICE].

[LINK]

When [TIMEFRAME] ends, the price goes back. That's the deal.

[YOUR NAME]

### P-3 — Downsell (post-launch)
**Purpose:** Catch the ones who didn't buy.
**Subjects:** "Didn't grab [PRODUCT]? Read this" / "A smaller yes" / "For the fence-sitters"
**Body:**
Hey [FIRST NAME],

You didn't grab [PRODUCT NAME] — no worries, no guilt.

But I don't want you to walk away empty-handed. So here's [LITE VERSION / PAYMENT PLAN / SINGLE MODULE] for [LOWER PRICE]:

[ONE-LINE DESCRIPTION]: [LINK]

It's the [CORE PIECE] without [WHAT'S EXCLUDED]. If you love it, you can upgrade later — I'll credit what you paid.

[YOUR NAME]

### P-4 — Bundle pitch
**Purpose:** Raise average order value.
**Subjects:** "Get everything (save [X]%)" / "The bundle is back" / "Why buy one..."
**Body:**
Instead of buying [PRODUCT A] and [PRODUCT B] separately, grab the bundle:

[BUNDLE NAME]: [LINK]
Includes: [LIST 3-5 items]
Price: [PRICE] (save [X]% vs. separate)

Bundles exist for one reason: you get more, I do less admin. Everybody wins.

Available until [DATE].

[YOUR NAME]

### P-5 — Bonus stack
**Purpose:** Sweeten the offer without discounting.
**Subjects:** "I just added [BONUS]" / "New bonus inside [PRODUCT]" / "This tips it over"
**Body:**
I just added a new bonus to [PRODUCT NAME]:

[BONUS NAME] — [2-sentence description of what it does for them].

It slots right in after [MODULE/SECTION]. Everyone who already bought gets it free — check your inbox.

New here? [LINK] — [PRICE], bonus included until [DATE].

[YOUR NAME]

### P-6 — Price increase warning
**Purpose:** Honest urgency before a raise.
**Subjects:** "Price goes up [DAY]" / "Last chance at [PRICE]" / "Heads up"
**Body:**
Short and honest, [FIRST NAME]:

[PRODUCT NAME] goes from [OLD PRICE] to [NEW PRICE] on [DATE].

Nothing changes except the price — same product, same bonuses, same guarantee. I'm raising it because [REASON: results are in / demand / added content].

Lock in [OLD PRICE]: [LINK]

[YOUR NAME]

### P-7 — Seasonal angle
**Purpose:** Tie the offer to a moment.
**Subjects:** "Your [SEASON] reset starts here" / "[HOLIDAY] + [OUTCOME]" / "New [SEASON], new [RESULT]"
**Body:**
[SEASON] is when everyone [COMMON BEHAVIOR — "sets goals they abandon by February"]. Let's do it differently.

[PRODUCT NAME] helps you [OUTCOME] with [MECHANISM] — and I'm taking [X]% off until [DATE] so there's no excuse.

[PRICE] instead of [PRICE]: [LINK]

Start [SEASON] with a system, not a wish.

[YOUR NAME]

### P-8 — Last hours
**Purpose:** Final push, short and direct.
**Subjects:** "Ends at midnight" / "[X] hours" / "Last email about this"
**Body:**
[FIRST NAME] — [OFFER] ends at midnight tonight.

[LINK]

That's the whole email. You know what it is, you know the price, you know the guarantee.

See you on the other side — or in the next email.

[YOUR NAME]

## CART CLOSE

### C-1 — Cart closing soon
**Purpose:** 24-hour warning.
**Subjects:** "24 hours left" / "Tomorrow it closes" / "[PRODUCT] — final day tomorrow"
**Body:**
[FIRST NAME], [PRODUCT NAME] closes tomorrow at [TIME].

What's inside one more time:
- [BENEFIT 1]
- [BENEFIT 2]
- [BENEFIT 3]

[PRICE]. [GUARANTEE one-liner.]

[LINK]

Tomorrow I'll send one last reminder. Then we move on.

[YOUR NAME]

### C-2 — The FAQ close
**Purpose:** Last-minute objections, final day.
**Subjects:** "Last day — your questions answered" / "Still thinking? Read this" / "Quick answers"
**Body:**
Cart closes tonight. Last-minute questions, answered fast:

**"Is this for beginners?"** [One-line answer.]
**"How much time does it take?"** [One-line answer.]
**"What if it doesn't work for me?"** [Guarantee one-liner.]
**"When do I get access?"** [One-line answer.]

[LINK] — closes at [TIME].

[YOUR NAME]

### C-3 — The personal nudge
**Purpose:** Human, low-pressure final push.
**Subjects:** "Can I ask you something?" / "A personal note" / "Between us"
**Body:**
Hey [FIRST NAME],

Cart closes in a few hours and I wanted to ask directly: what's holding you back?

Not a sales tactic — I genuinely want to know. Sometimes it's a question I can answer in one reply. Sometimes the timing's just wrong, and that's fine.

Reply and tell me. I'll be here until close.

[YOUR NAME]

P.S. The link, in case: [LINK]

### C-4 — The final hour
**Purpose:** Last call, maximum clarity.
**Subjects:** "1 hour" / "Closing in 60 minutes" / "Final call"
**Body:**
60 minutes, [FIRST NAME].

[PRODUCT NAME] — [PRICE] — closes at [TIME].

[LINK]

After that: [WHAT HAPPENS]. No extensions — [REASON].

[YOUR NAME]

### C-5 — Doors closed (post-cart)
**Purpose:** Close the loop, keep goodwill.
**Subjects:** "Doors are closed" / "That's a wrap" / "What happens now"
**Body:**
Hey [FIRST NAME],

[PRODUCT NAME] is closed. Thanks to everyone who joined — [RESULT: "we had X new students" / "welcome to the new members"].

If you missed it: [WHAT HAPPENS NEXT — waitlist link / next opening estimate / alternative product].

No hard feelings either way. The free content keeps coming, and the next opportunity will too.

[YOUR NAME]

## RE-ENGAGEMENT

### R-1 — The check-in
**Purpose:** Wake up cold subscribers.
**Subjects:** "Still there, [FIRST NAME]?" / "We need to talk" / "Are you still into [TOPIC]?"
**Body:**
Hey [FIRST NAME],

You joined my list [TIMEFRAME] ago, and I haven't heard from you since. No guilt — inboxes are brutal.

Quick question: are you still working on [GOAL]? Reply YES or NO.

If yes — I'll send you my best [RESOURCE] this week.
If no — tell me what you're into now, or just unsubscribe below. I'd rather have 500 engaged readers than 5,000 ghosts.

[YOUR NAME]

### R-2 — The best-of
**Purpose:** Re-prove value to the disengaged.
**Subjects:** "My 5 best emails (in case you missed them)" / "Start here" / "The greatest hits"
**Body:**
In case my emails have been piling up unread, here's the best of [TIMEFRAME]:

1. [EMAIL TOPIC] — [one-line hook]: [LINK if archived]
2. [EMAIL TOPIC] — [one-line hook]
3. [EMAIL TOPIC] — [one-line hook]
4. [EMAIL TOPIC] — [one-line hook]
5. [EMAIL TOPIC] — [one-line hook]

Pick one. If none of them interest you, we're probably not a fit — and that's okay. Unsubscribe link's at the bottom, no hard feelings.

[YOUR NAME]

### R-3 — The survey
**Purpose:** Learn + re-engage in one move.
**Subjects:** "2 questions (30 seconds)" / "Help me help you" / "What do you actually want?"
**Body:**
[FIRST NAME], I want to send you better emails. Help me out — 2 questions, 30 seconds:

1. What's your #1 struggle with [TOPIC] right now?
2. What would you like me to cover more?

[LINK TO SURVEY or "just hit reply"]

Everyone who answers gets [INCENTIVE — my [RESOURCE] free]. Because your time isn't free, and I know it.

[YOUR NAME]

### R-4 — The breakup
**Purpose:** Clean the list, final attempt.
**Subjects:** "Should I stop emailing you?" / "Last chance to stay" / "Breaking up?"
**Body:**
Hey [FIRST NAME],

You haven't opened an email in [TIMEFRAME]. I'm cleaning house — inactive readers get removed [DATE].

If you want to stay: click here [LINK] or just reply "STAY."

If not: do nothing. You'll be removed automatically, and I wish you well.

No hard feelings either way. I'd rather email people who want to hear from me.

[YOUR NAME]

### R-5 — The welcome back
**Purpose:** Re-onboard the re-engaged.
**Subjects:** "Welcome back" / "You stayed — here's what's next" / "Glad you're here"
**Body:**
You clicked STAY — I appreciate that, [FIRST NAME].

Here's what you've missed and what's coming:

[2-3 sentences: the most important thing from the gap period.]

[2-3 sentences: what's coming next — a launch, a series, a resource.]

To get the most out of this list: reply to this email with your #1 goal for [TIMEFRAME]. I read every reply.

Good to have you back.

[YOUR NAME]

## AFFILIATE PROMO

### A-1 — The genuine recommendation
**Purpose:** Promote a partner product authentically.
**Subjects:** "I don't recommend many [PRODUCTS]. This one's different." / "What I actually use for [TASK]" / "My honest take on [PRODUCT]"
**Body:**
Full disclosure: this is an affiliate email. If you buy through my link, I earn a commission — at zero extra cost to you.

I only send these when I'd recommend the thing anyway. [PRODUCT NAME] by [CREATOR] qualifies.

[2-3 sentences: what it is and what it did for you specifically.]

[1-2 sentences: who it's for / not for.]

[LINK]

That's the pitch. Back to regular programming tomorrow.

[YOUR NAME]

### A-2 — The bonus bribe
**Purpose:** Promote with an exclusive bonus.
**Subjects:** "Buy [PRODUCT] through me, get [BONUS]" / "My exclusive bonus" / "Don't buy [PRODUCT] yet"
**Body:**
Quick one, [FIRST NAME]:

[PRODUCT NAME] is [ONE-LINE DESCRIPTION]. I'm an affiliate, so here's my deal:

Buy through my link before [DATE] → you also get my [BONUS NAME] free.

[BONUS]: [2-sentence description of the bonus and why it complements the product].

My link: [AFFILIATE LINK]
Then forward your receipt to [EMAIL] and I'll send the bonus.

[YOUR NAME]

### A-3 — The case study
**Purpose:** Sell via your own results with the product.
**Subjects:** "What happened when I used [PRODUCT]" / "My [X] results with [PRODUCT]" / "Case study"
**Body:**
I [USED/TESTED] [PRODUCT NAME] for [TIMEFRAME]. Here's what happened:

[BEFORE]: [1-2 sentences]
[WHAT I DID]: [2-3 sentences — specific]
[AFTER]: [1-2 sentences with numbers if you have them]

My verdict: [1-2 sentences — honest, including any caveat].

If you want the same: [AFFILIATE LINK] (affiliate link — costs you nothing extra).

[YOUR NAME]

### A-4 — The comparison
**Purpose:** Help them choose, position the pick.
**Subjects:** "[PRODUCT A] vs [PRODUCT B]: my pick" / "Which [TOOL] should you buy?" / "I tested both"
**Body:**
People keep asking: [PRODUCT A] or [PRODUCT B]?

I tested both. Short version:

[CRITERION 1]: [A wins/loses because...]
[CRITERION 2]: [A wins/loses because...]
[CRITERION 3]: [A wins/loses because...]

My pick: [WINNER] — [one-line reason].

[LINK — affiliate]

Caveat: if [SPECIFIC SITUATION], get [LOSER] instead. Right tool for the right job.

[YOUR NAME]

### A-5 — The last-call affiliate
**Purpose:** Final push on a partner promo.
**Subjects:** "Ends tonight: [PRODUCT]" / "Last call (affiliate)" / "[X] hours on [PRODUCT]"
**Body:**
Last call on [PRODUCT NAME], [FIRST NAME].

[ONE-LINE REMINDER of what it is + price.]

My affiliate link: [LINK]

[ONE-LINE reminder of your bonus if offered.]

Ends [TIME]. After that, [WHAT HAPPENS].

[YOUR NAME]

## SOCIAL PROOF

### S-1 — The testimonial story
**Purpose:** Let a customer sell for you.
**Subjects:** "[NAME] did [RESULT] in [TIMEFRAME]" / "This email is about [NAME]" / "Proof, not promises"
**Body:**
Meet [NAME].

[2-3 sentences: where they started — the struggle, specific.]

They [USED/BOUGHT] [PRODUCT NAME] and [2-3 sentences: what they did, what changed — specific result].

Their words: "[SHORT QUOTE in their voice.]"

[NAME]'s not special. They just [DID THE THING]. You can too:

[LINK]

[YOUR NAME]

### S-2 — The numbers email
**Purpose:** Aggregate proof, authority.
**Subjects:** "The numbers are in" / "[X] [CUSTOMERS/STUDENTS] later..." / "By the numbers"
**Body:**
Quick update on [PRODUCT NAME]:

- [X] customers
- [X]% [RESULT METRIC — completion rate, satisfaction, etc.]
- [X] [TESTIMONIALS/REVIEWS] collected
- [NOTABLE RESULT or press mention]

[2 sentences: what these numbers tell you about who this works for.]

If you're still deciding: [LINK]

The numbers don't lie. The only question is whether you'll be in the next batch.

[YOUR NAME]

### S-3 — The screenshot collection
**Purpose:** Visual proof, relatable wins.
**Subjects:** "Screenshots > promises" / "Real people, real results" / "Your inbox vs. theirs"
**Body:**
I collected this week's wins from [PRODUCT NAME] users:

"[SHORT WIN 1 — specific]" — [NAME]
"[SHORT WIN 2 — specific]" — [NAME]
"[SHORT WIN 3 — specific]" — [NAME]

[2 sentences: the pattern across these wins — what they all did.]

Your win could be next week's screenshot: [LINK]

[YOUR NAME]

### S-4 — The expert endorsement
**Purpose:** Borrow authority.
**Subjects:** "[EXPERT] said what about [PRODUCT]?" / "When [EXPERT] noticed" / "Endorsed"
**Body:**
[EXPERT NAME] ([CREDENTIAL — "runs a 7-figure [NICHE] business" / "author of [BOOK]"]) doesn't endorse products. Except this once:

"[THEIR QUOTE about your product — 1-2 sentences.]"

[2 sentences: why their opinion matters in this space, and what specifically they validated.]

I'm not name-dropping for fun. When someone at that level notices, it's worth passing along.

[LINK]

[YOUR NAME]
