============================================================
PLR VAULT — WHAT'S INSIDE
============================================================

You just bought a shortcut. Here's how to use it.

------------------------------------------------------------
THE 4 PACKS
------------------------------------------------------------
1. 01-2026-planner/ — The 2026 Planner Pack
   12 monthly calendars (real 2026 dates), weekly spreads, daily
   focus pages, habit tracker, goal planner, monthly review.
   SVG format: crisp at any size, editable, print-ready.

2. 02-30-day-content-calendar.md — The 30-Day Content Calendar
   30 days of postable content for a digital-product side hustle:
   theme, format, hook, full caption draft, and CTA for every day.
   Post it as-is or rewrite in your voice.

3. 03-email-swipes.md — The 50-Email Swipe Pack
   50 complete emails across 8 categories: welcome, nurture,
   launch, promo, cart close, re-engagement, affiliate, and
   social proof. Each with 3 subject lines and [BRACKET]
   placeholders. Swap, send, sell.

4. 04-mini-course-outlines.md — The Mini-Course Outline Pack
   8 complete course blueprints: promise, buyer, price point,
   4-6 modules with lessons and objectives, worksheets, and
   upsell ideas. Add your voice and record.

Plus: LICENSE-PLR.txt — your rights, in plain English.
Read it first. It's one page.

------------------------------------------------------------
WHO THIS IS FOR
------------------------------------------------------------
Creators, coaches, freelancers, and side-hustlers who want to
sell digital products without starting from a blank page.
Use it yourself, rebrand it, or resell it — the license
covers all three.

------------------------------------------------------------
HOW TO EDIT THE PLANNER IN CANVA (2 MINUTES)
------------------------------------------------------------
1. Go to canva.com and create a design (US Letter or A4).
2. Uploads > Upload the SVG file you want as your background.
3. Drag it onto the page and stretch it to fill.
4. Lock it (right-click > Lock) so it stays put.
5. Add text boxes on top for your branding, colors, and fonts.
6. Download as PDF Print for a finished planner page.

That's it — the SVG is your editable base, Canva is your
design layer.

------------------------------------------------------------
QUICK-START: YOUR FIRST 3 DAYS
------------------------------------------------------------
Day 1: Read LICENSE-PLR.txt. Know your rights.
Day 2: Pick ONE pack. Rebrand it — your name, your colors,
       your voice. Don't aim for perfect; aim for yours.
Day 3: List it. Gumroad, Stan Store, your own checkout —
       wherever your buyers are. Price it $9-$47 and ship.

The bundle cost you $9.95. One sale at $17 and you're
profitable. Everything after that is the business.

Go build.
