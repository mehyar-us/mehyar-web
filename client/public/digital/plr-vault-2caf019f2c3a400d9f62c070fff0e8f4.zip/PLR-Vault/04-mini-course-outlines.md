# PLR Vault — Mini-Course Outline Pack
8 complete course blueprints. Add your voice, your examples, your branding — record, launch, keep 100%.

---

## Course 1: The Faceless Content Engine
**Promise:** Build a faceless short-form channel that grows to monetization in 90 days.
**Ideal buyer:** Camera-shy creators, side-hustlers, anyone who wants content income without personal branding.
**Suggested price:** $47

### Module 1: Pick Your Lane
- Lesson 1.1: The 5 faceless formats that actually monetize — Objective: choose a format matched to your skills and revenue goal.
- Lesson 1.2: Niche math — demand vs. competition — Objective: validate a niche using search and competitor data before creating anything.
- Lesson 1.3: Your 90-day positioning statement — Objective: write a one-line channel promise that guides every video.
- Lesson 1.4: Steal like an analyst — Objective: deconstruct 10 top performers in your niche into repeatable patterns.
**Worksheet:** Niche validation scorecard (demand, competition, monetization paths — scored 1-5).
**Upsell idea:** 100 done-for-you faceless video scripts in your niche.

### Module 2: The Production System
- Lesson 2.1: The $0 tool stack — Objective: set up scripting, voiceover, editing, and thumbnails with free tools.
- Lesson 2.2: Scripting for retention — Objective: write 30-second scripts using the hook–tension–payoff structure.
- Lesson 2.3: Voiceovers that don't sound robotic — Objective: produce natural-sounding narration with pacing and emphasis.
- Lesson 2.4: Editing for the algorithm — Objective: cut videos with pattern interrupts every 3 seconds.
**Worksheet:** Script template with retention checkpoints.
**Upsell idea:** Voiceover + editing done-for-you pack (30 videos).

### Module 3: Publishing & Growth
- Lesson 3.1: The posting cadence that compounds — Objective: build a sustainable 1-video-a-day schedule.
- Lesson 3.2: Hooks, titles, and thumbnails — Objective: raise click-through with testable packaging.
- Lesson 3.3: Reading analytics without drowning — Objective: identify the 3 metrics that predict growth and ignore the rest.
- Lesson 3.4: Doubling down on winners — Objective: turn one hit video into a series format.
**Worksheet:** Weekly analytics review template (what to check, what to change).
**Upsell idea:** 1:1 channel audit with a 30-day action plan.

### Module 4: Monetization
- Lesson 4.1: The 4 revenue streams for faceless channels — Objective: map ads, affiliates, sponsors, and digital products to your niche.
- Lesson 4.2: Affiliate income from video one — Objective: place affiliate links that convert without hurting trust.
- Lesson 4.3: Your first digital product — Objective: design a $9-$27 product your audience already wants.
- Lesson 4.4: Sponsors at small subscriber counts — Objective: pitch micro-sponsors with a one-page media kit.
**Worksheet:** Revenue roadmap — which stream to add at 1K, 10K, 50K followers.
**Upsell idea:** The digital product starter kit (templates + checkout setup guide).

---

## Course 2: Email List from Zero
**Promise:** Go from 0 to your first 1,000 engaged subscribers without ads.
**Ideal buyer:** New creators, bloggers, freelancers who know email matters but haven't started.
**Suggested price:** $37

### Module 1: Foundations
- Lesson 1.1: Why email beats every platform — Objective: understand ownership, deliverability, and revenue-per-subscriber math.
- Lesson 1.2: Picking your email platform — Objective: choose a provider based on list size, budget, and automation needs.
- Lesson 1.3: The technical 30 minutes — Objective: set up SPF, DKIM, and DMARC so your emails land in inboxes.
- Lesson 1.4: Your sender identity — Objective: define your from-name, voice, and sending cadence.
**Worksheet:** Platform comparison checklist + setup tracker.
**Upsell idea:** Done-for-you email tech setup.

### Module 2: The Lead Magnet
- Lesson 2.1: Lead magnets that convert at 40%+ — Objective: design a micro-solution freebie your audience can't ignore.
- Lesson 2.2: The 5 formats ranked — Objective: pick checklist, template, calculator, mini-course, or swipe file based on your niche.
- Lesson 2.3: Building it in a weekend — Objective: produce a polished lead magnet with a repeatable production process.
- Lesson 2.4: The landing page — Objective: write a signup page with one job: the email address.
**Worksheet:** Lead magnet idea generator (10 prompts + scoring rubric).
**Upsell idea:** 20 done-for-you lead magnet templates.

### Module 3: Traffic Without Ads
- Lesson 3.1: The content-to-email bridge — Objective: turn every post into a subscriber with soft CTAs.
- Lesson 3.2: Borrowed audiences — Objective: get featured in newsletters, podcasts, and communities in your niche.
- Lesson 3.3: SEO for email capture — Objective: rank one high-intent article that captures emails for years.
- Lesson 3.4: The welcome sequence that sells — Objective: write 5 emails that onboard, bond, and soft-pitch.
**Worksheet:** 30-day traffic action calendar.
**Upsell idea:** The welcome sequence swipe pack (this Vault's emails, rebranded).

### Module 4: Keep Them Opening
- Lesson 4.1: Subject lines that survive the inbox — Objective: write subject lines using curiosity, specificity, and pattern breaks.
- Lesson 4.2: The 80/20 email calendar — Objective: plan a month of emails in one sitting: 80% value, 20% pitch.
- Lesson 4.3: Segmentation without complexity — Objective: tag subscribers by interest with 3 simple rules.
- Lesson 4.4: Re-engagement before deletion — Objective: run a win-back sequence that saves or cleanly removes cold subs.
**Worksheet:** Monthly email planner + subject line swipe bank.
**Upsell idea:** Monthly done-for-you newsletter service pitch template.

---

## Course 3: Notion Systems for Freelancers
**Promise:** Run your entire freelance business from one Notion workspace — clients, projects, money, content.
**Ideal buyer:** Freelancers and solo consultants drowning in scattered tools and spreadsheets.
**Suggested price:** $57

### Module 1: The Foundation
- Lesson 1.1: Workspace architecture — Objective: design a dashboard-first structure: Clients, Projects, Finance, Content.
- Lesson 1.2: Databases, not documents — Objective: understand relational databases by building a linked Clients → Projects setup.
- Lesson 1.3: Templates that save hours — Objective: create project, invoice, and content templates with one click.
- Lesson 1.4: Views for every mode — Objective: build kanban, calendar, and table views of the same data.
**Worksheet:** Workspace map — sketch your 4 databases and their relations before building.
**Upsell idea:** The complete pre-built freelancer workspace template.

### Module 2: Client Management
- Lesson 2.1: The CRM that runs itself — Objective: track leads, proposals, and follow-ups in one pipeline.
- Lesson 2.2: Proposals and onboarding — Objective: templatize proposals, contracts, and kickoff checklists.
- Lesson 2.3: Project delivery tracking — Objective: manage milestones, deliverables, and client feedback per project.
- Lesson 2.4: The offboarding sequence — Objective: systematize testimonials, referrals, and rebooking.
**Worksheet:** Client journey checklist — every touchpoint from lead to referral.
**Upsell idea:** Proposal + contract template bundle.

### Module 3: Money Clarity
- Lesson 3.1: Income tracking that takes 5 minutes — Objective: log invoices and payments with automated status rollups.
- Lesson 3.2: Expense and tax-ready records — Objective: categorize expenses so tax season is a filter, not a panic.
- Lesson 3.3: The pipeline forecast — Objective: project next-quarter revenue from your CRM data.
- Lesson 3.4: Pricing decisions from data — Objective: use real hourly rates to raise prices with confidence.
**Worksheet:** Monthly money review template.
**Upsell idea:** Freelancer tax prep checklist + accountant handoff template.

### Module 4: Content & Growth
- Lesson 4.1: The content database — Objective: run ideation → draft → publish from one pipeline.
- Lesson 4.2: Repurposing tracker — Objective: multiply each piece of content across platforms systematically.
- Lesson 4.3: The weekly review ritual — Objective: run a 30-minute Friday review that keeps the system honest.
- Lesson 4.4: Scaling the system — Objective: add automations and a VA handoff doc when you outgrow solo.
**Worksheet:** Weekly review checklist.
**Upsell idea:** 1:1 Notion workspace audit + rebuild.

---

## Course 4: Canva Design for Coaches
**Promise:** Design scroll-stopping brand content in Canva — no designer, no ugly templates.
**Ideal buyer:** Coaches, consultants, and course creators whose DIY graphics undermine their prices.
**Suggested price:** $47

### Module 1: Brand Foundations
- Lesson 1.1: Your 5-element brand kit — Objective: lock fonts, colors, textures, photo style, and logo usage in Canva's brand kit.
- Lesson 1.2: Typography that looks expensive — Objective: pair fonts using contrast rules that signal premium pricing.
- Lesson 1.3: Color psychology for coaches — Objective: choose a palette that matches your coaching promise.
- Lesson 1.4: The 60-second brand audit — Objective: score any design against your brand kit before publishing.
**Worksheet:** Brand kit builder — fill in every element with examples.
**Upsell idea:** Custom Canva brand kit designed for you.

### Module 2: Social Content
- Lesson 2.1: Carousel architecture — Objective: design carousels with hook slide, tension build, and CTA slide.
- Lesson 2.2: Reels covers that get clicks — Objective: create consistent, readable covers in 3 minutes each.
- Lesson 2.3: Quote graphics that don't look cheap — Objective: use hierarchy and whitespace to elevate text posts.
- Lesson 2.4: Story templates — Objective: build reusable story frames for polls, Q&As, and launches.
**Worksheet:** 10-post content design checklist.
**Upsell idea:** 100 done-for-you Canva templates in your niche.

### Module 3: Sales Assets
- Lesson 3.1: Lead magnet design — Objective: lay out PDFs that feel premium, not homemade.
- Lesson 3.2: Sales page graphics — Objective: design mockups, guarantee badges, and bonus stacks that lift conversion.
- Lesson 3.3: Slide decks that hold attention — Objective: build webinar/course slides with one idea per slide.
- Lesson 3.4: Testimonial graphics — Objective: turn client wins into shareable proof assets.
**Worksheet:** Sales asset inventory — every graphic your funnel needs, checked off.
**Upsell idea:** Sales page graphic pack (mockups, badges, dividers).

### Module 4: Systems & Speed
- Lesson 4.1: The template library — Objective: build a personal template system so nothing starts from blank.
- Lesson 4.2: Batch design days — Objective: produce a month of graphics in one 3-hour session.
- Lesson 4.3: AI + Canva workflow — Objective: generate on-brand imagery and copy with AI, finish in Canva.
- Lesson 4.4: Hiring a designer later — Objective: write a brief and brand handoff doc when you outgrow DIY.
**Worksheet:** Batch day planner.
**Upsell idea:** Monthly template drop subscription.

## Course 5: The $9 Tripwire Funnel
**Promise:** Build a self-liquidating funnel: a $9 front-end offer that pays for the ads that sell your core product.
**Ideal buyer:** Digital product sellers stuck paying for traffic that doesn't convert to profit.
**Suggested price:** $67

### Module 1: Tripwire Strategy
- Lesson 1.1: How self-liquidating funnels work — Objective: understand the math: front-end covers ad cost, back-end is profit.
- Lesson 1.2: Choosing your tripwire product — Objective: pick a high-value, low-price offer from your existing assets.
- Lesson 1.3: The value ladder — Objective: map tripwire → core offer → upsell so each step earns the next.
- Lesson 1.4: Funnel economics — Objective: calculate break-even CPA and target conversion rates before spending a dollar.
**Worksheet:** Funnel math calculator (CPA, conversion, break-even).
**Upsell idea:** Done-for-you funnel math review.

### Module 2: Building the Funnel
- Lesson 2.1: The tripwire sales page — Objective: write a single-page pitch optimized for impulse buys.
- Lesson 2.2: Checkout and order bumps — Objective: add a one-click bump that 20-30% of buyers take.
- Lesson 2.3: The upsell sequence — Objective: build a one-time-offer page that converts warm buyers.
- Lesson 2.4: Delivery and onboarding — Objective: deliver instantly and onboard buyers toward the core offer.
**Worksheet:** Funnel page checklist — every element, in order.
**Upsell idea:** Tripwire page template pack.

### Module 3: Traffic
- Lesson 3.1: The $10/day test protocol — Objective: validate the funnel with small-budget Meta/TikTok tests.
- Lesson 3.2: Creative that converts cold traffic — Objective: produce 5 ad angles from one product.
- Lesson 3.3: Reading the first 7 days — Objective: diagnose weak links: CTR, landing conversion, bump take-rate.
- Lesson 3.4: Scaling winners — Objective: increase budget on proven funnels without breaking economics.
**Worksheet:** 7-day traffic test tracker.
**Upsell idea:** Ad creative swipe file (50 proven angles).

### Module 4: Optimization
- Lesson 4.1: A/B testing that matters — Objective: test headlines, prices, and bumps in priority order.
- Lesson 4.2: Email follow-up for non-buyers — Objective: recover 15-25% of abandoners with a 3-email sequence.
- Lesson 4.3: Raising the tripwire price — Objective: test $9 → $17 → $27 as trust and proof accumulate.
- Lesson 4.4: From funnel to flywheel — Objective: reinvest profits into content and affiliates for compounding traffic.
**Worksheet:** Quarterly optimization roadmap.
**Upsell idea:** 1:1 funnel teardown.

---

## Course 6: AI Content Repurposing System
**Promise:** Turn one long-form piece into 30 days of platform-native content with AI — in under 2 hours a week.
**Ideal buyer:** Busy founders, coaches, and creators sitting on unrepurposed videos, podcasts, or newsletters.
**Suggested price:** $37

### Module 1: The Source Material
- Lesson 1.1: Choosing your pillar format — Objective: pick the one long-form format you'll commit to weekly.
- Lesson 1.2: Structuring for repurposing — Objective: create pillar content with extractable moments built in.
- Lesson 1.3: The content bank — Objective: store transcripts and assets in a searchable repurposing library.
**Worksheet:** Pillar content planner — topic, key moments, extraction targets.
**Upsell idea:** Transcription + content bank setup service.

### Module 2: The AI Workflow
- Lesson 2.1: Prompting for platform-native output — Objective: write prompts that produce reels scripts, threads, and emails — not generic summaries.
- Lesson 2.2: The extraction pass — Objective: pull 10+ standalone ideas from one transcript with AI.
- Lesson 2.3: Voice preservation — Objective: train your AI workflow on your tone so output sounds like you.
- Lesson 2.4: Human finishing pass — Objective: edit AI drafts in 5 minutes per piece without rewriting.
**Worksheet:** Prompt library — 15 copy-paste prompts for every format.
**Upsell idea:** Custom prompt pack tuned to your voice.

### Module 3: Platform Distribution
- Lesson 3.1: One idea, five platforms — Objective: adapt a single insight for TikTok, Instagram, X, LinkedIn, and email.
- Lesson 3.2: Scheduling systems — Objective: queue 30 days of content in one sitting.
- Lesson 3.3: Format-specific tweaks — Objective: adjust hooks, length, and CTAs per platform without starting over.
**Worksheet:** 30-day distribution calendar template.
**Upsell idea:** Done-for-you repurposing (we turn your weekly video into 30 posts).

### Module 4: Measure & Compound
- Lesson 4.1: What to track — Objective: identify the 4 metrics that show repurposing ROI.
- Lesson 4.2: Doubling down — Objective: turn top-performing repurposed pieces into new pillar content.
- Lesson 4.3: Building the library — Objective: compound 6 months of repurposing into an evergreen content asset.
**Worksheet:** Monthly repurposing ROI review.
**Upsell idea:** Evergreen content library build-out.

---

## Course 7: Digital Product Launch in 14 Days
**Promise:** Go from idea to launched digital product in 14 days — with buyers, not just a product.
**Ideal buyer:** First-time sellers who've been "researching" for months.
**Suggested price:** $77

### Module 1: Days 1-3 — Validate
- Lesson 1.1: The 10-conversation rule — Objective: confirm demand with real conversations before building.
- Lesson 1.2: Defining the transformation — Objective: write a one-sentence promise a stranger would pay for.
- Lesson 1.3: Competitor reconnaissance — Objective: map 5 competitors and find your wedge.
- Lesson 1.4: Pre-selling before building — Objective: collect 10 pre-orders or emails with a waitlist page.
**Worksheet:** Validation tracker — conversations, quotes, verdict.
**Upsell idea:** Waitlist page template + copy.

### Module 2: Days 4-8 — Build
- Lesson 2.1: Minimum viable product — Objective: scope the smallest version that delivers the promise.
- Lesson 2.2: Rapid creation sprints — Objective: produce the core content in 5 focused sessions.
- Lesson 2.3: Packaging for perceived value — Objective: name, structure, and design the product to feel worth 10x the price.
- Lesson 2.4: The delivery setup — Objective: configure checkout, delivery, and buyer email in one afternoon.
**Worksheet:** Build sprint planner — day-by-day task list.
**Upsell idea:** Product packaging + mockup design service.

### Module 3: Days 9-11 — Pre-Launch
- Lesson 3.1: The runway content — Objective: publish 3 pieces that seed demand without pitching.
- Lesson 3.2: Early-bird list — Objective: convert waitlist subscribers into day-one buyers.
- Lesson 3.3: Affiliate and partner outreach — Objective: recruit 5 partners with a simple revenue-share pitch.
- Lesson 3.4: Launch asset checklist — Objective: prepare every email, post, and page before cart opens.
**Worksheet:** Launch asset inventory.
**Upsell idea:** Launch email sequence swipe pack.

### Module 4: Days 12-14 — Launch & Beyond
- Lesson 4.1: Cart open — Objective: execute the 3-day launch sequence (open, proof, close).
- Lesson 4.2: Handling launch day chaos — Objective: triage questions, bugs, and feedback without panic.
- Lesson 4.3: The post-launch debrief — Objective: extract lessons and testimonials while they're fresh.
- Lesson 4.4: Evergreen transition — Objective: convert the launch into an always-open funnel.
**Worksheet:** Launch debrief template.
**Upsell idea:** 1:1 launch strategy call.

---

## Course 8: The Membership Starter Kit
**Promise:** Launch a $19-$49/month membership your first 50 members will love — and stay in.
**Ideal buyer:** Creators with an audience who want recurring revenue without a massive course library.
**Suggested price:** $97

### Module 1: The Concept
- Lesson 1.1: Membership models that work at small scale — Objective: choose community, content-drop, or hybrid based on your strengths.
- Lesson 1.2: The retention-first promise — Objective: design a membership people join for the outcome and stay for the belonging.
- Lesson 1.3: Pricing for retention — Objective: price between $19-$49 using value-per-month math.
- Lesson 1.4: The founding member launch — Objective: recruit 25 founding members before building the full library.
**Worksheet:** Membership concept one-pager.
**Upsell idea:** Founding member launch email sequence.

### Module 2: The Experience
- Lesson 2.1: The first 7 days — Objective: design onboarding that gets members their first win fast.
- Lesson 2.2: The content rhythm — Objective: plan a monthly cadence: one drop, one live, one community moment.
- Lesson 2.3: Community without chaos — Objective: set up channels, norms, and moderation that run themselves.
- Lesson 2.4: The member dashboard — Objective: build a simple hub so members always know what's new.
**Worksheet:** 90-day content calendar for the membership.
**Upsell idea:** Membership platform setup (Circle/Discord/Skool).

### Module 3: Retention
- Lesson 3.1: Why members leave — Objective: identify the 5 churn triggers and build defenses for each.
- Lesson 3.2: The engagement loop — Objective: create weekly rituals members look forward to.
- Lesson 3.3: Win-back sequences — Objective: recover canceling members with targeted save offers.
- Lesson 3.4: Ascension paths — Objective: design the next step for members who outgrow the basics.
**Worksheet:** Churn defense checklist.
**Upsell idea:** Retention audit for existing memberships.

### Module 4: Growth
- Lesson 4.1: Member-get-member — Objective: launch a referral program that rewards sharing.
- Lesson 4.2: The public flywheel — Objective: turn member wins into marketing that recruits new members.
- Lesson 4.3: Partnerships and bundles — Objective: grow through aligned creators' audiences.
- Lesson 4.4: Scaling past 500 — Objective: add team, systems, and pricing tiers without losing the culture.
**Worksheet:** Growth experiment tracker.
**Upsell idea:** 1:1 membership growth roadmap call.
